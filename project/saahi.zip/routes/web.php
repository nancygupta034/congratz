<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home')->middleware('auth');

Route::group(['middleware' => 'auth'], function () {
	Route::get('table-list', function () {
		return view('pages.table_list');
	})->name('table');

	Route::get('typography', function () {
		return view('pages.typography');
	})->name('typography');

	Route::get('icons', function () {
		return view('pages.icons');
	})->name('icons');

	Route::get('map', function () {
		return view('pages.map');
	})->name('map');

	Route::get('notifications', function () {
		return view('pages.notifications');
	})->name('notifications');

	Route::get('rtl-support', function () {
		return view('pages.language');
	})->name('language');

	Route::get('upgrade', function () {
		return view('pages.upgrade');
	})->name('upgrade');
});

Route::group(['middleware' => 'auth'], function () {
	//Route::resource('user', 'UserController', ['except' => ['show']]);


	//Routes for profile
	Route::get('profile', ['as' => 'profile.edit', 'uses' => 'ProfileController@edit']);
	Route::put('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@update']);
	Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'ProfileController@password']);

	//routes for admin/users
    Route::get('/users', 'UserController@index')->name('user.index');
    Route::get('/user/add', 'UserController@create')->name('user.add');
    Route::post('/add/user', 'UserController@store')->name('user.create');
    Route::get('user/view/{id}', 'UserController@viewUser')->name('user.view');
    Route::get('/user/{id}/edit', 'UserController@editUser')->name('user.edit');
    Route::post('/user/update/{id}', 'UserController@updateUser')->name('user.update');
    Route::get('/user/delete/{id}', 'UserController@deleteUser')->name('user.delete');
    Route::get('/user/block/{id}', 'UserController@updateStatus')->name('user.block');
    Route::post('/change/password', 'UserController@changePassword')->name('change.password');

    //routes for products
    Route::post('/add/product', 'ProductController@store')->name('product.create');
    Route::get('/edit/product/{id}', 'ProductController@edit')->name('product.edit');
    Route::get('/delete/product/{id}', 'ProductController@delete')->name('product.delete');
    Route::get('/view/product/{id}', 'ProductController@view')->name('product.view');
});

