<?php $__env->startSection('content'); ?>
<div class="container" style="height: auto;">
  <div class="row justify-content-center">
      <div class="col-lg-7 col-md-8 text-center">
          <img src="<?php echo e(asset('/material/img/Saahi_Logo.png')); ?>" class="picture-src" id="blah1" title="" style="margin-top: 24px;height: 250px;width: 55%;border-radius: 50%;">
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'off-canvas-sidebar', 'activePage' => 'home', 'title' => __('Material Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancing-projects\saahi-new\saahi\resources\views/welcome.blade.php ENDPATH**/ ?>