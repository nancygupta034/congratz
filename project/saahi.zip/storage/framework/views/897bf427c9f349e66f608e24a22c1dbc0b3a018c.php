<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary card-header-icon">
              <div class="card-icon">
                <i class="material-icons">people</i>
              </div>   
              <h4 class="card-title ">Users</h4>
              <a href="<?php echo e(route('user.add')); ?>" class="btn btn-primary btn-link add_user_btn">Add User</a>
          </div>
          <div class="card-body users-table-card-body">
            <div class="table-responsive">
              <table class="table" id="users_table">
                <thead class=" text-primary">
                  <th>
                    Name
                  </th>
                  <th>
                    Email
                  </th>
                  <th>
                    Product Owned
                  </th>
                  <th>
                    Actions
                  </th>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      Dakota Rice
                    </td>
                    <td>
                      dakota@yopmail.com
                    </td>
                    <td>
                      5
                    </td>
                    <td class="text-primary">
                      <a class="info-lnk" title="Edit User" href="<?php echo e(route('user.edit')); ?>">
                        <i class="material-icons action_btn">edit</i>
                      </a>
                      <a class="block-lnk block_btn" title="Block User" id="block_user" href="javascript:;">
                        <i class="material-icons action_btn">block</i>
                      </a>
                      <a href="javascript:;" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                        <i class="material-icons action_btn">close</i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      Minerva Hooper
                    </td>
                    <td>
                      Curaçao@yopmail.com
                    </td>
                    <td>
                      5
                    </td>
                    <td class="text-primary">
                      <a class="info-lnk" title="Edit User" href="<?php echo e(route('user.edit')); ?>">
                        <i class="material-icons action_btn">edit</i>
                      </a>
                      <a class="block-lnk" title="Edit User" href="#">
                        <i class="material-icons action_btn">block</i>
                      </a>
                      <a href="javascript:;" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                        <i class="material-icons action_btn">close</i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    
                    <td>
                      Sage Rodriguez
                    </td>
                    <td>
                      sage@yopmail.com
                    </td>
                    <td>
                      5
                    </td>
                    <td class="text-primary">
                      <a class="info-lnk" title="Edit User" href="<?php echo e(route('user.edit')); ?>">
                        <i class="material-icons action_btn">edit</i>
                      </a>
                      <a class="block-lnk" title="Edit User" href="#">
                        <i class="material-icons action_btn">block</i>
                      </a>
                      <a href="javascript:;" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                        <i class="material-icons action_btn">close</i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    
                    <td>
                      Philip Chaney
                    </td>
                    <td>
                      Philip@yopmail.com
                    </td>
                    <td>
                      5
                    </td>
                    <td class="text-primary">
                      <a class="info-lnk" title="Edit User" href="<?php echo e(route('user.edit')); ?>">
                        <i class="material-icons action_btn">edit</i>
                      </a>
                      <a class="block-lnk" title="Edit User" href="#">
                        <i class="material-icons action_btn">block</i>
                      </a>
                      <a href="javascript:;" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                        <i class="material-icons action_btn">close</i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      Doris Greene
                    </td>
                    <td>
                      Malawi
                    </td>
                    <td>
                      5
                    </td>
                    <td class="text-primary">
                      <a class="info-lnk" title="Edit User" href="<?php echo e(route('user.edit')); ?>">
                        <i class="material-icons action_btn">edit</i>
                      </a>
                      <a class="block-lnk" title="Edit User" href="#">
                        <i class="material-icons action_btn">block</i>
                      </a>
                      <a href="javascript:;" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                        <i class="material-icons action_btn">close</i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      Mason Porter
                    </td>
                    <td>
                      Chile
                    </td>
                    <td>
                      5
                    </td>
                    <td class="text-primary">
                      <a class="info-lnk" title="Edit User" href="<?php echo e(route('user.edit')); ?>">
                        <i class="material-icons action_btn">edit</i>
                      </a>
                      <a class="block-lnk" title="Edit User" href="#">
                        <i class="material-icons action_btn">block</i>
                      </a>
                      <a href="javascript:;" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                        <i class="material-icons action_btn">close</i>
                      </a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>

        $(document).ready(function () {


            (function () {
                $('#users_table').dataTable({
                  responsive: true,
                  select:true ,
                  lengthChange: false,
                  searching: false
                });
            })();

            $('#users_table').on( 'select.dt', function ( e, dt, type, indexes ) {
                 var data = dt.rows(indexes).data();
                  console.log(data);
            });
            //on click of delete button
            $(document).on('click', '.dlt_btn', function (e) {
               e.preventDefault(); 
               Swal.fire({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#5e104b',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    Swal.fire({
                      title: 'Deleted!',
                      text: "User has been deleted.",
                      icon: 'success',
                      confirmButtonColor: '#5e104b',
                    })
                  }
                })      
            });
            //on click of block button  
            $(document).on('click', '.block_btn', function (e) {
               e.preventDefault(); 
               Swal.fire({
                  title: 'Are you sure?',
                  text: "",
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#5e104b',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, block it!'
                }).then((result) => {
                  if (result.value) {
                    Swal.fire({
                      title: 'Blocked!',
                      text: "User has been blocked.",
                      icon: 'success',
                      confirmButtonColor: '#5e104b',
                    })
                  }
                })      
            });   
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'titlePage' => __('Table List'),'title' => 'Users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancing-projects\saahi-new\saahi\resources\views/pages/table_list.blade.php ENDPATH**/ ?>