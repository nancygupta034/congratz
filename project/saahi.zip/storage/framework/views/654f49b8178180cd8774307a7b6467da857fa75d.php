<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          
            <form method="post" action="<?php echo e(route('change.password')); ?>"  autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">Change Password</h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body ">
                <?php if(Session::has('message')): ?>
                    <div id="snackbar">
                      


                      <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>Notification !</strong> <?php echo e(Session::get('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    </div>
                <?php else: ?>
                    <div id="snackbar" style="display: none;"></div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password">Current Password</label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"  type="password" name="current_password" id="input-password" placeholder="Enter Current Password" />
                      <?php if($errors->has('password')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password">New Password</label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" input type="password" name="password" id="input-password" placeholder="Enter New Password" />
                      <?php if($errors->has('password')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Confirm Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="<?php echo e(__('Confirm Password')); ?>" />
                       <?php if($errors->has('password_confirmation')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('password_confirmation')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary btn-link">Update Password</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
      $(document).ready(function () {
        //call function for snackbar
        myFunction();

        //function for snackbar
        function myFunction() {
          console.log('dfs');
            var x = document.getElementById("snackbar");

            x.className = "show";
            if (x.style.display = 'block') {
              setTimeout(function () {
                  x.hide();
                 // x.className = x.className.replace("show", "");
              }, 3000);
            }
            
        }
  });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'user-management', 'titlePage' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancing-projects\saahi-new\saahi\resources\views/users/changePassword.blade.php ENDPATH**/ ?>