<footer class="footer auth-footer">
  <div class="container-fluid">

    <div class="copyright text-center auth-copyright">
      &copy;
      <script>
          document.write(new Date().getFullYear())
      </script>. All rights reserved.
    </div>
  </div>
</footer><?php /**PATH D:\freelancing-projects\saahi-new\saahi\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>