 @extends('layouts.app', ['activePage' => 'user-management', 'titlePage' => __('User Management')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form class="form-horizontal">
            @csrf
            @method('put')

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">User Details</h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body">
                <div class="row">
                  <label class="col-sm-2 col-form-label">{{ __('Name') }}</label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control id="input-name" type="text" value="{{$user['name']}}" aria-required="true" disabled />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label">{{ __('Email') }}</label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" id="input-email" type="email" disabled value="{{$user['email']}}" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label">Product Owned</label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" id="input-name" type="text" disabled value="{{$count}}" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>


      <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary card-header-icon">
              <div class="card-icon">
                <i class="material-icons">assignment</i>
              </div>   
              <h4 class="card-title ">Products Owned</h4>
              <a href="#" class="btn btn-primary btn-link add_user_btn add_product_btn">Add New Product</a>
          </div>
          <div class="card-body users-table-card-body">
            <div class="table-responsive">
              <table class="table" id="users_table">
                <thead class=" text-primary">
                  <th>
                    Name of Product
                  </th>
                  <th>
                    Product Type
                  </th>
                  <th>
                    Number of Channels
                  </th>
                  <th>
                    Actions
                  </th>
                </thead>
                <tbody>
                  @foreach($products as $product)
                    <tr>
                      <td>
                        <a data-url="{{ route('product.view',$product->id) }}" href="javascript:;" class="view_btn">
                          {{$product->name}}
                        </a>
                      </td>
                      <td>
                          <a data-url="{{ route('product.view',$product->id) }}" href="javascript:;" class="view_btn">
                            {{$product->type}}
                          </a>
                      </td>
                      <td>
                          <a data-url="{{ route('product.view',$product->id) }}"  href="javascript:;" class="view_btn">
                            {{$product->channels}}
                          </a>
                      </td>
                      <td class="text-primary">
                        <a class="info-lnk edit_btn" title="Edit Product" href="javascript:;" data-url="{{route('product.edit', $product->id)}}">
                          <i class="material-icons action_btn">edit</i>
                        </a>
                        <a href="javascript:;" id="delete" title="Delete Product" class="danger-lnk dlt_btn" data-url="{{route('product.delete', $product->id)}}">
                          <i class="material-icons action_btn">close</i>
                        </a>
                      </td>
                    </tr>
                  @endforeach  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>

  <!-- Modal -->
    <div id="productModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header product-modal-header">
                                      
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                      <i class="material-icons close-product-modal">clear</i>
                    </button>
                    <h4 class="card-title text-center product-title">Add Product</h4>
                </div>
                <div class="modal-body">
                    <form id="add_product">
                        {{csrf_field()}}
                        <input type="hidden" name="user_id" value="{{$user->id}}">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">Name of Product</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="name"placeholder="Enter Name of Product" id="product_name">
                                        <span id="name"></span>
                                        <input type="hidden" name="product_id" id="product_id">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">URL</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="url" class="form-control" name="url"
                                               placeholder="Enter a valid URL" id="product_url">
                                        <span id="url"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">SSL Port</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="port" placeholder="Enter SSL Port" id="product_port">
                                        <span id="port"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">User Name</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="user_name"
                                               placeholder="Enter User Name" id="product_user_name">
                                        <span id="user_name"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">Password</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" name="password"
                                               placeholder="Enter Password" id="product_password">
                                               <span toggle="#input-product-password" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
                                        <span id="password"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">Product Type</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <select class="form-control" name="type" id="product_type">
                                            <option disabled selected>Select Product Type</option>
                                            <option id="sensor" >Sensor + Actuation</option>
                                            <option id="actuation">Actuation</option>
                                        </select>
                                        <span id="type"></span>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">No. of Channels</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" name="channels"
                                               placeholder="Enter No. of Channels" id="product_channel">
                                        <span id="channels"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <button type="button" class="btn btn-rose pull-right"
                                                id="saveBtn">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

  <!-- Modal -->
    <div id="productViewModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header product-modal-header">       
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                      <i class="material-icons close-product-modal">clear</i>
                    </button>
                    <h4 class="card-title text-center product-title">View Product</h4>
                </div>
                <div class="modal-body">
                    <form id="view_product">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">Name of Product</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="product_view_name" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">URL</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="url" class="form-control" id="product_view_url" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">SSL Port</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="product_view_port" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">User Name</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="product_view_user_name" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">Password</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" id="product_view_password" readonly>
                                        <span toggle="#input-view-password" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">Product Type</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="product_view_type" readonly >
                                    </div>
                                </div>    
                            </div>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label class="bmd-label">No. of Channels</label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="product_view_channel" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script>
        $(document).ready(function () {
            //on click of add teacher
            $(".add_product_btn").on('click', function (e) {
                e.preventDefault();
                $('#modalHeading').html("Add New Product");
                $('#productModal').modal({
                    refresh: true,
                    show: true
                });
            });

            //send data to controller
            $("#saveBtn").on('click', function(e){
                var data = $("#add_product").serialize();
                $.ajax({
                    type: "POST",
                    url: "{{route('product.create')}}",
                    data: data,
                    success: function (response) {
                      if (response.status == 200) {
                          Swal.fire({
                            text: response.message,
                            icon: 'success',
                            confirmButtonColor: '#5e104b',
                            closeOnConfirm: true,
                          });
                          $('#productModal').modal({
                              refresh: true,
                              show: false
                          });
                          location.reload();
                      }
                      else{
                          console.log('Something went wrong');
                      }   
                    },
                    error: function (response) {
                        $(".error_msg").remove();
                        $.each(response.responseJSON.errors, function (index, value) {
                            $("#" + index).html('<span class="error_msg">' + value + '</span>');
                        });
                    }
                });
            });

            //on click of edit button
            $(document).on('click', ".edit_btn", function (e) {
                var url = $(this).data('url');
                $.get(url, function (data) {
                    $('.error_msg').remove();
                    $('#add_product').trigger("reset");
                    $('#modalHeading').html("Edit Product");
                    $('#productModal').modal("show");
                    if (data.product) {
                        $('#product_id').val(data.product.id);
                        $('#product_name').val(data.product.name);
                        $('#product_channel').val(data.product.channels);
                        $('#product_password').val(data.password);
                        $('#product_url').val(data.product.url);
                        $('#product_port').val(data.product.port);
                        $('#product_user_name').val(data.product.user_name);
                        
                        if (data.product.type == 'Actuation') {
                            $("#actuation").attr('selected',true);
                        }
                        else {
                            $("#sensor").attr('selected',true);
                        }
                    }
                });
            });


            //on click of view button
            $(document).on('click', ".view_btn", function (e) {
              console.log('sdAS');

                var url = $(this).data('url');
                $.get(url, function (data) {
                    $('#productViewModal').modal("show");
                    if (data.product) {
                        $('#product_view_name').val(data.product.name);
                        $('#product_view_channel').val(data.product.channels);
                        $('#product_view_password').val(data.password);
                        $('#product_view_url').val(data.product.url);
                        $('#product_view_port').val(data.product.port);
                        $('#product_view_user_name').val(data.product.user_name);
                        $('#product_view_type').val(data.product.type);
                    }
                });
            });


            //on click of delete button
            $(document).on('click', ".dlt_btn", function (e) {
               e.preventDefault();
               var url = $(this).data('url'); 
               Swal.fire({
                  title: 'Are you sure?',
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#5e104b',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                     $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                          if (response.status == 200) {
                              Swal.fire({
                                title: 'Deleted!',
                                text: "Product has been deleted.",
                                icon: 'success',
                                confirmButtonColor: '#5e104b',
                                closeOnConfirm: true,
                              });
                              location.reload();
                          }
                          else{
                              console.log('Something went wrong');
                          }
                            
                        },
                        error: function (response) {
                            console.log('there is an error');
                        }
                    });
                    
                  }
                })    
            });

            $('.toggle-password').on('click', function(e){
            if ($(this).hasClass('fa-eye-slash')) {
                $(this).addClass('fa-eye');
                $(this).removeClass('fa-eye-slash');
                $('#product_password').attr("type","text");
                
                
            }
            else {
                $(this).addClass('fa-eye-slash');
                $(this).removeClass('fa-eye');
                $('#product_password').attr("type","password");

            }
          })
        });
    </script>
@endpush



