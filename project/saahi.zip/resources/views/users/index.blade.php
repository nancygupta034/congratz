@extends('layouts.app', ['activePage' => 'user-management', 'titlePage' => __('User Management')])

@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary card-header-icon">
              <div class="card-icon">
                <i class="material-icons">people</i>
              </div>   
              <h4 class="card-title ">Users</h4>
              <a href="{{ route('user.add') }}" class="btn btn-primary btn-link add_user_btn">Add User</a>
          </div>
          <div class="card-body users-table-card-body">
            <div class="table-responsive">
              <table class="table" id="users_table">
                <thead class=" text-primary">
                  <th>
                    Name
                  </th>
                  <th>
                    Email
                  </th>
                  <th>
                    Product Owned
                  </th>
                  <th>
                    Actions
                  </th>
                </thead>
                <tbody>
                  @foreach($users as $user)
                  
                    <tr>
                      
                        <td>
                          <a href="{{ route('user.view',base64_encode($user->id)) }}" class="view_btn">
                            {{$user->name}}
                           </a>
                        </td>
                        <td>
                          <a href="{{ route('user.view',base64_encode($user->id)) }}" class="view_btn">
                            {{$user->email}}
                          </a>
                        </td>
                        <td>
                          @php
                            $count=App\Product::where('user_id',$user->id)->get()->count();
                          @endphp
                          <a href="{{ route('user.view',base64_encode($user->id)) }}" class="view_btn">
                            {{$count}}
                          </a>
                        </td>
                        <td class="text-primary">
                          <a class="info-lnk" title="Edit User" href="{{ route('user.edit',base64_encode($user->id)) }}">
                            <i class="material-icons action_btn">edit</i>
                          </a>
                          <a class="block-lnk block_btn" title="Block User" id="block_user" href="javascript:;" data-url="{{route('user.block',$user->id)}}">
                            @if($user->is_blocked == 1)
                              <i class="material-icons action_btn">verified_user</i>
                            @else
                              <i class="material-icons action_btn">block</i>
                            @endif
                          </a>
                          <a href="javascript:;" data-url="{{route('user.delete',$user->id)}}" id="delete" title="Delete User" class="danger-lnk dlt_btn dlt-lnk">
                            <i class="material-icons action_btn">close</i>
                          </a>
                        </td>

                    </tr>
                  
                  @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
@push('scripts')
    <script>

        $(document).ready(function () {
            // (function () {
            //     $('#users_table').dataTable({
            //       responsive: true,
            //       select:true ,
            //       lengthChange: false,
            //       searching: false
            //     });
            // })();

            
            //on click of delete button
            $(document).on('click', '.dlt_btn', function (e) {
               e.preventDefault();
               var url = $(this).data('url'); 
               Swal.fire({
                  title: 'Are you sure?',
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#5e104b',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                     $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                          if (response.status == 200) {
                              Swal.fire({
                                title: 'Deleted!',
                                text: "User has been deleted.",
                                icon: 'success',
                                confirmButtonColor: '#5e104b',
                                closeOnConfirm: true,
                              });
                              location.reload();
                          }
                          else{
                              console.log('Something went wrong');
                          }
                            
                        },
                        error: function (response) {
                            console.log('there is an error');
                        }
                    });
                    
                  }
                })      
            });
            //on click of block button  
            $(document).on('click', '.block_btn', function (e) {
               e.preventDefault(); 
               var url = $(this).data('url');
               Swal.fire({
                  title: 'Are you sure?',
                  text: "",
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#5e104b',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes!'
                }).then((result) => {
                  console.log(result);
                  if (result.value) {
                    $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                          if (response.status == 200) {
                              Swal.fire({
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#5e104b',
                              });
                              location.reload();
                          }
                          else{
                              console.log('Something went wrong', response.message);
                          }
                            
                        },
                        error: function (response) {
                            console.log('there is an error');
                        }
                    });
                    
                  }
                })      
            });   
        });
    </script>
@endpush
