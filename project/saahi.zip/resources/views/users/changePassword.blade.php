@extends('layouts.app', ['activePage' => 'user-management', 'titlePage' => __('User Management')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          
            <form method="post" action="{{route('change.password')}}"  autocomplete="off" class="form-horizontal">
            @csrf
            @method('post')

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">Change Password</h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body ">
                @if(Session::has('message'))
                    <div id="snackbar">
                      


                      <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>Notification !</strong> {{ Session::get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    </div>
                @else
                    <div id="snackbar" style="display: none;"></div>
                @endif
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password">Current Password</label>
                  <div class="col-sm-7">
                    <div class="form-group{{ $errors->has('password') ? ' has-danger' : '' }}">
                      <input class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}"  type="password" name="current_password" id="input-password" placeholder="Enter Current Password" />
                      @if ($errors->has('password'))
                        <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('password') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password">New Password</label>
                  <div class="col-sm-7">
                    <div class="form-group{{ $errors->has('password') ? ' has-danger' : '' }}">
                      <input class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" input type="password" name="password" id="input-password" placeholder="Enter New Password" />
                      @if ($errors->has('password'))
                        <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('password') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password-confirmation">{{ __('Confirm Password') }}</label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="{{ __('Confirm Password') }}" />
                       @if ($errors->has('password_confirmation'))
                        <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('password_confirmation') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary btn-link">Update Password</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
@endsection
@push('scripts')
  <script>
      $(document).ready(function () {
        //call function for snackbar
        myFunction();

        //function for snackbar
        function myFunction() {
          console.log('dfs');
            var x = document.getElementById("snackbar");

            x.className = "show";
            if (x.style.display = 'block') {
              setTimeout(function () {
                  x.hide();
                 // x.className = x.className.replace("show", "");
              }, 3000);
            }
            
        }
  });
  </script>
@endpush