<footer class="footer">
    <div class="container">
        
        <div class="copyright text-center">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>. All rights reserved.
        </div>
    </div>
</footer>