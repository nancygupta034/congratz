<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Product;
use DB;
use Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;

class UserController extends Controller
{
    /**
     * Display a listing of the users
     *
     * @param  \App\User  $model
     * @return \Illuminate\View\View
     */
    public function index(User $model)
    {
        $users = $model::where('email', '!=', 'admin@saahi.com')->get();
        return view('users.index', compact('users') ,['users' => $model->paginate(15)]);
    }

    /**
     * Show the form for creating a new user
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * Store a newly created user in storage
     *
     * @param  \App\Http\Requests\UserRequest  $request
     * @param  \App\User  $model
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request, User $model)
    {
        $this->validate($request, [
            'name' => 'required|max:35',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
        ]);
        $model->create($request->merge(['password' => Hash::make($request->get('password')),
            'encrypted_password' => Crypt::encrypt($request->get('password'))])->all());

        return redirect()->route('user.index')->withStatus(__('User successfully created.'));
    }

    /**
     * Show the form for editing the specified user
     *
     * @param  \App\User  $user
     * @return \Illuminate\View\View
     */
    public function editUser($id)
    {
        $user = User::findOrFail(base64_decode($id));
        if ($user) {
            $password =  Crypt::decrypt($user->encrypted_password);

            return view('users.edit', compact('user','password'));
        }
        
        return view('users.edit', compact('user'));
    }

    public function viewUser($id)
    {
        $user = User::findOrFail(base64_decode($id));
        if ($user) {
            $products = Product::where('user_id', $user->id)->get();
            $count = $products->count();
            return view('users.view', compact('user','products','count'));
        }
        
    }


    public function updateUser(Request $request, User $model, $id)
    {

        $this->validate($request, [
            'name' => 'required|max:35',
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);
        $user = $model::findOrFail(base64_decode($id));
        $user->update(array_merge($request->all(), ['password' => Hash::make($request->get('password')),
            'encrypted_password' => Crypt::encrypt($request->get('password'))]));

        return redirect()->route('user.index')->withStatus(__('User successfully updated.'));
    }

  

    /**
     * Remove the specified user from storage
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteUser($id)
    {
        $user = User::where('id', $id)->first();
        if ($user) {
            $user->delete();
            $arr = array('message' => "User deleted successfully", 'status' => 200);
        }
        else {
            $arr = array('message' => "No data found", 'status' => 401);
        }
        
        return response()->json($arr);
    }

    public function updateStatus ($id)
    {
        
        $user = User::where('id', $id)->first();
        if ($user) {

            if ($user->is_blocked == 1) {
                $update = DB::table('users')
                ->where('id', $id)
                ->update(['is_blocked' => 0]);
                
                $arr = array('message' => "User unblocked successfully", 'status' => 200);
            }
            else {
                $update = DB::table('users')
                ->where('id', $id)
                ->update(['is_blocked' => 1]);
                
                
                $arr = array('message' => "User blocked successfully", 'status' => 200);
            }
        }
        else{
            $arr = array('message' => "Data not found", 'status' => 401);
        }
        
        return response()->json($arr);
    }


    public function changePassword(Request $request)
    {
        $this->validate($request, [
            'current_password' => 'required|max:35|min:6',
            'password' => 'required|min:6',
            'password_confirmation' => 'required|same:password',
        ]);
        $data = $request->all();
        $user = User::findOrFail(auth()->user()->id);

        if (!Hash::check($data['current_password'], $user->password)) {
            return back()->with(['message' => "Current password doesn't match with our database"]);
        }
        $password = $request->get('password');
        $user->update([
            'password' => Hash::make($request->get('password')),
            'encrypted_password' => Crypt::encrypt($request->get('password')),
        ]);

        return redirect('login')->with(Auth::logout()); 
    }
}
