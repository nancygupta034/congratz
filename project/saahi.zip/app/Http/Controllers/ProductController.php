<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class ProductController extends Controller
{
    /**
     * Display a listing of the users
     *
     * @param  \App\User  $model
     * @return \Illuminate\View\View
     */
    // public function index(User $model)
    // {
    //     $users = $model::where('email', '!=', 'admin@saahi.com')->get();
    //     return view('users.index', compact('users') ,['users' => $model->paginate(15)]);
    // }


    /**
     * Store a newly created user in storage
     *
     * @param  \App\Http\Requests\UserRequest  $request
     * @param  \App\User  $model
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request, Product $model)
    {

        $this->validate($request, [
            'name' => 'required|max:35',
            'url' => 'required',
            'port' => 'required',
            'user_name' => 'required',
            'type' => 'required',
            'channels' => 'required',
            'password' => 'required|min:6',
        ]);
        if ($request->get('product_id')) {
            $data =  $model::where('id', $request->get('product_id'))->first();
            $request->except('_token');
            $product = $data->update($request->merge(['password' => Crypt::encrypt($request->get('password'))])->all()) ;

            if ($product) {
                $arr = array('message' => "Product updated successfully", 'status' => 200);
            }
            else{
                $arr = array('message' => "There is some error. Please try again", 'status' => 401);
            }
        }
        else {
            $product = $model->create($request->merge(['password' => Crypt::encrypt($request->get('password'))])->all());

            if ($product) {
                $arr = array('message' => "Product created successfully", 'status' => 200);
            }
            else{
                $arr = array('message' => "There is some error. Please try again", 'status' => 401);
            }
        }
        
        return response()->json($arr);
    }

    /**
     * Show the form for editing the specified user
     *
     * @param  \App\User  $user
     * @return \Illuminate\View\View
     */
    public function edit(Request $request,$id)
    {
        
        $product = Product::where('id', $id)->first();
        if ($product) {
            $password =  Crypt::decrypt($product->password);
            $arr = array('product' => $product,'password' => $password);

            return response()->json($arr);
        } else {

            return abort(404);
        }

    }

    public function view($id)
    {
        $product = Product::where('id', $id)->first();
        if ($product) {
            $password =  Crypt::decrypt($product->password);
            $arr = array('product' => $product,'password' => $password);

            return response()->json($arr);
        } else {

            return abort(404);
        }
        
    }


    /**
     * Remove the specified user from storage
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete($id)
    {
        $product = Product::where('id', $id)->first();
        if ($product) {
            $product->delete();
            $arr = array('message' => "Product deleted successfully", 'status' => 200);
        }
        else {
            $arr = array('message' => "No data found", 'status' => 401);
        }
        
        return response()->json($arr);
    }

    
}
