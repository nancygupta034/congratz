<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Validator;
use DB;
use App\User;
use App\Product;
use \Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\View\View;


class ApiController extends Controller
{

    

     /**
     * Login user and create token
     *
     * @param  [string] email
     * @param  [string] password
     * @return [string] access_token
     * @return [string] token_type
     * @return [string] expires_at
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json_encode(['error' => $validator->errors(), 'status' => 401], 401);
        }
        $credentials = request(['email', 'password']);
        //dd($credentials);
        if(!Auth::attempt(['email' => request('email'), 'password' => request('password')]))
            return response()->json([
                'message' => 'Unauthorized',
                'status'    => '401',  
            ], 401);
        $user = $request->user();
        if ($user->is_blocked == 1) {
            return response()->json([
                'message' => 'Admin has blocked your account',
                'status'    => '401',  
            ], 401);
        }
        elseif ($user->deleted_at != NULL) {
            return response()->json([
                'message' => 'Admin has deleted your account.',
                'status'    => '401',  
            ], 401);
        }
        else{
            $products = Product::where('user_id', $user->id)->get();
            $tokenResult = $user->createToken('Saahi');
            $token = $tokenResult->token;
            $userModel['userId'] = $user->id;
            $userModel['name'] = $user->name;
            $userModel['email'] = $user->email;
            $userModel['accessToken'] = $tokenResult->accessToken;
            $token->save();
            return response()->json([
                'status' => 200,
                'message' => 'Logeed In Successfully',
                'userModel' => $userModel,
                'token_type' => 'Bearer',
                'productOwned' => $products,

            ]); 
        }  
    }


    public function tokenLogin(Request $request)
    {
        
        
        if ($request->user()->is_blocked == 1) {
            return response()->json([
                'message' => 'Admin has blocked your account',
                'status'    => '401',  
            ], 401);
        }
        elseif ($request->user()->deleted_at != NULL) {
            return response()->json([
                'message' => 'Admin has deleted your account.',
                'status'    => '401',  
            ], 401);
        }
        else{
            $products = Product::where('user_id', $request->user()->id)->get();
            $userModel['userId'] = $request->user()->id;
            $userModel['name'] = $request->user()->name;
            $userModel['email'] = $request->user()->email;
            return response()->json([
                'status' => 200,
                'message' => 'Logeed In Successfully',
                'userModel' => $userModel,
                'token_type' => 'Bearer',
                'productOwned' => $products,

            ]); 
        }
    }

    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }
}
    

