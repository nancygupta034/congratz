<?php

namespace App\Http\Controllers;

use App\User;
use App\Product;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {

        $totalUsers = User::where('email', '!=', 'admin@saahi.com')->get()->count();
        $totalProducts = Product::all()->count();
        return view('dashboard',compact('totalProducts','totalUsers'));
    }
}
